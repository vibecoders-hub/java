/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parta2;

/**
 *
 * @author HP
 */
import java.util.*;
public class PartA2 {
    public static void main(String args[])
    {
        int n,i,count=1,slarge,ssmall;
        
        Scanner data = new Scanner(System.in);
        
        System.out.println("Enter the Size of Array: ");
        n = data.nextInt();
        if(n<3)
        {
           System.out.println("Enter the array with atleast 3 elements");
           return;
        }
        
        Integer a[]=new Integer[n];
        System.out.println("Enter any "+n+" elements:");
        for(i=0;i<n;i++){
           a[i] = data.nextInt();
           if(i>0&&a[i]==a[i-1]){
               count++;
           }
        }
        
        if(count==n)
        {
           System.out.println("Array values must be unqiue: ");
           System.exit(0);
        }
        else
        {
           Arrays.sort(a);
           ssmall=a[1];
           slarge=a[a.length-2]; 
           System.out.println("Secound Largest Element: "+slarge);
           System.out.println("Secound Smallest Element: "+ssmall);
        }
    }
}
