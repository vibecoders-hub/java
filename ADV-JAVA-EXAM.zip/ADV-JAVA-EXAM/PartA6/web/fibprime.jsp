<%-- 
    Document   : fibprime
    Created on : 27 May 2026, 9:04:11 pm
    Author     : HP
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>fibonacci sries and prime no</title>
    </head>
    <body>
        <h1>Fibonacci series</h1>
        <%
            int a=0,b=1,c,i;
            for(i=0;i<10;i++)
            {
            c=a+b;
            out.println(c+"&nbsp;&nbsp;");
            a=b;
            b=c;
        }
        %>
        
        <h1>prime no</h1>
        <%
            int ct=0,n=0,k=1,j=1;
            while(n<10)
            {
            j=1;
            ct=0;
            while(j<=k)
            {
            if(k%j==0)
            {
            ct++;
        }
        j++;
        }
        if(ct==2)
        {
        out.println(k+"&nbsp;&nbsp");
        n++;
        }
        k++;
        }
        %>
    </body>
</html>
