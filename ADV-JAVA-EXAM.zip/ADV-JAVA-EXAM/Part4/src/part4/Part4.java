/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part4;

/**
 *
 * @author HP
 */
import java.util.Scanner;

public class Part4 {

    static String toggleCharacters(String str) {

        StringBuilder result = new StringBuilder();

        for(char ch : str.toCharArray()) {

            if(Character.isUpperCase(ch))
                result.append(Character.toLowerCase(ch));

            else if(Character.isLowerCase(ch))
                result.append(Character.toUpperCase(ch));

            else
                result.append(ch);
        }

        return result.toString();
    }

    static String swapCharacters(String str) {

        StringBuilder result = new StringBuilder();

        String[] words = str.split("\\s+");

        for(String word : words) {

            if(word.length() % 2 == 0) {

                for(int i = 0; i < word.length(); i += 2) {

                    result.append(word.charAt(i + 1));
                    result.append(word.charAt(i));
                }

                result.append(" ");
            }
        }

        return result.toString().trim();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a String: ");
        String data = sc.nextLine();

        System.out.println("Swapped String: " + swapCharacters(data));
        System.out.println("Toggled String: " + toggleCharacters(data));
    }
}
